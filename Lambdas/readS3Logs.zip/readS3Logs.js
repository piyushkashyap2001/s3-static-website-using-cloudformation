const aws = require("aws-sdk");
const zlib = require("zlib");
const s3 = new aws.S3({ apiVersion: "2006-03-01" });
const cw = new aws.CloudWatchLogs({ apiVersion: "2015-01-28" });
const AlreadyExists = "ResourceAlreadyExistsException";
const months = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
];

// Thanks https://github.com/caolan/async/blob/master/lib/waterfall.js

function cascade(tasks, callback, ignoreError) {
  callback = callback || (() => undefined);
  ignoreError = ignoreError || (() => false);
  if (!tasks || !tasks.length) {
    return callback();
  }

  let taskIndex = 0;
  const nextTask = args => tasks[taskIndex++].apply(null, [next, ...args]);
  const next = (err, ...args) => {
    const shouldIgnoreError = err && ignoreError(err, taskIndex);
    return (err && !shouldIgnoreError) || taskIndex === tasks.length
      ? callback.apply(null, [shouldIgnoreError ? null : err, ...args])
      : nextTask(args);
  };

  nextTask([]);
}

// Thanks http://docs.aws.amazon.com/AmazonS3/latest/dev/LogFormat.html (see: Time)
// Thanks http://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/AccessLogs.html#BasicDistributionFileFormat

function parseTime(dateString) {
  let dg = null;

  // Amazon "Server Access Log" Format Time pattern:
  //  strftime [%d/%b/%Y:%H:%M:%S %z] (ex. [06/Feb/2014:00:00:38 +0000])
  dg = dateString.match(
    /(\d{2})\/([A-Z][a-z]{2})\/(\d{4}):(\d{2}):(\d{2}):(\d{2})/
  );
  if (dg) {
    return Date.UTC(dg[3], months.indexOf(dg[2]), dg[1], dg[4], dg[5], dg[6]);
  }

  // ISO 8601 (ex. 2014-05-23T01:13:11Z) or
  // Amazon "CloudFront Access Log" Format Time pattern:
  //  strftime %Y-%m-%d%t%H:%M:%S (ex. 2014-05-23 01:13:11)
  dg = dateString.match(/(\d{4})-(\d{2})-(\d{2})[T\s](\d{2}):(\d{2}):(\d{2})/);
  if (dg) {
    return Date.UTC(dg[1], parseInt(dg[2], 10) - 1, dg[3], dg[4], dg[5], dg[6]);
  }

  return Date.now();
}

// Thanks https://github.com/rajatkumar/cloudwatchlogger/blob/master/lib/CloudWatchLogsStream.js

exports.handler = (event, context, callback) => {
  console.log("this is s3 event ==> " + JSON.stringify(event, null, 4));
  let sequenceToken = null;

  const eventRecord = event.Records[0]; // only ever one record
  const {
    bucket: { name: Bucket },
    object
  } = eventRecord.s3;
  const Key = decodeURIComponent(object.key.replace(/\+/g, " "));
  console.log("this is key==" + Key);
  const pathComponents = Key.split("/");
  console.log("this is pathComponents==" + pathComponents);
  //  const logGroupName = pathComponents.splice(0, 1)[0]; // first path component
  let logGroupName = "";
  if (pathComponents.includes("cloudfront")) {
    logGroupName = process.env.CF_LOG_GROUP; //eventRecord.s3.bucket.name;
  } else {
    logGroupName = process.env.S3_LOG_GROUP; //eventRecord.s3.bucket.name;
  }

  console.log("this is logGroupName==" + logGroupName);
  //  const logId = pathComponents.join('/'); // all but the first path component (joined with '/')
  const logId = pathComponents[0];
  console.log("this is logId==" + logId);
  // If logId contains a date in the YYYY-mm-dd format, use that as the stream name
  const deliveryDate = logId.match(/\d{4}-\d{2}-\d{2}/);
  console.log("this is deliveryDate==" + deliveryDate);
  //  const logStreamName = deliveryDate ? deliveryDate[0] : logId;
  const logStreamName = pathComponents[pathComponents.length - 1]; //logId;
  console.log("this is logStreamName==" + logStreamName);
  function getObject(cb) {
    console.log("getbucket==" + Bucket + "  key== " + Key);
    s3.getObject({ Bucket, Key }, cb);
  }

  function deleteObject(cb) {
    s3.deleteObject({ Bucket, Key }, cb);
  }
  function transformS3Obj(cb, getObjectResponse) {
    if (pathComponents.includes("cloudfront")) {
      zlib.gunzip(getObjectResponse.Body, cb);
    } else {
      cb(null, getObjectResponse.Body);
    }
  }
  function parseLogEvents(cb, getObjectResponse) {
    console.log(
      "this is getObjectResponse ==>" +
        JSON.stringify(getObjectResponse, null, 4)
    );
    cb(
      null,
      getObjectResponse
        .toString()
        .trim()
        .split("\n")
        .reduce((a, line) => {
          // Ignore lines that begin with # (to accommodate CloudFront format)
          //console.log('individual lines ==> ' + line);
          if (!line.startsWith("#")) {
            // Append log file source to the message body
            a.push({
              message: line.trim() + ` s3://${Bucket}/${Key}`,
              timestamp: parseTime(line)
            });

            console.log("Parsed: ", a[a.length - 1]);
          } else {
            console.log("Ignored: ", line);
          }
          return a;
        }, [])
    );
  }

  function putLogEvents(cb, logEvents) {
    // hack for cloudfront , to make log events in chronological order, otherwise putLogEvents throw error.
    logEvents = logEvents.sort(function(a, b) {
      return a.timestamp - b.timestamp;
    });
    console.log(
      "these are the log events ==> " + JSON.stringify(logEvents, null, 4)
    );
    if (!logEvents.length) {
      return cb(new Error("Nothing to log"));
    }
    cw.putLogEvents(
      { logStreamName, logGroupName, logEvents, sequenceToken },
      cb
    );
  }

  function createStream(cb) {
    cw.createLogStream({ logGroupName, logStreamName }, cb);
  }

  function createGroup(cb) {
    cw.createLogGroup({ logGroupName }, cb);
  }

  function describeStream(cb) {
    cw.describeLogStreams(
      { logGroupName, logStreamNamePrefix: logStreamName, limit: 1 },
      cb
    );
  }

  function setSequenceToken(cb, data) {
    console.log("this is data ===========> " + JSON.stringify(data, null, 4));
    // If sequenceToken is missing, the stream may have just been created
    const valid = data && data.logStreams && data.logStreams.length;
    // sequenceToken = !valid ? null : data.logStreams[0].uploadSequenceToken;
    console.log("this is valida value ==>" + valid);
    sequenceToken = !valid ? null : null;
    console.log("this is sequencetoken value ==> " + sequenceToken);
    cb(null);
  }

  function createLogger(cb) {
    // Ignore AlreadyExists exceptions (they just mean there is nothing to do before continuing)
    cascade([createGroup, createStream], cb, err => err.code === AlreadyExists);
  }

  cascade(
    [
      createLogger,
      describeStream,
      setSequenceToken,
      getObject,
      transformS3Obj,
      parseLogEvents,
      putLogEvents,
      deleteObject
    ],
    callback
  );
};
