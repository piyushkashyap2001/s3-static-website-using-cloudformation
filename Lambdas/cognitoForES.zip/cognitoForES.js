var AWS = require("aws-sdk");
AWS.config.update({ region: process.env.AWS_REGION });
var response = require("cfn-response");
console.log("within lambda function");
function elasticsearchCognitoOption(event, context, callback) {
  try {
    var es = new AWS.ES({ apiVersion: "2015-01-01" });
    switch (event.RequestType) {
      case "Create":
      case "Update":
        es.updateElasticsearchDomainConfig(
          {
            DomainName: event.ResourceProperties.ESDomain,
            CognitoOptions: {
              Enabled: true,
              IdentityPoolId: event.ResourceProperties.IdentityPoolId,
              RoleArn: event.ResourceProperties.RoleArn,
              UserPoolId: event.ResourceProperties.UserPoolId
            }
          },
          function(err, data) {
            if (err) {
              console.log(err, err.stack);
              response.send(event, context, callback, response.FAILED, {
                Error: err.message
              });
            } else {
              response.send(event, context, callback, response.SUCCESS);
            }
          }
        );
        break;
      case "Delete":
        response.send(event, context, callback, response.SUCCESS);
        break;
    }
  } catch (error) {
    console.error(
      `CognitoUserPoolDomain Error for request type ${event.RequestType}:`,
      error
    );
    response.send(event, context, callback, response.FAILED, {
      Error: error.message
    });
  }
}

function cognitoUserPoolDomain(event, context, callback) {
  try {
    var cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider();
    switch (event.RequestType) {
      case "Create":
        cognitoIdentityServiceProvider.createUserPoolDomain(
          {
            UserPoolId: event.ResourceProperties.UserPoolId,
            Domain: event.ResourceProperties.Domain
          },
          function(err, data) {
            if (err) {
              console.log(err, err.stack);
              response.send(event, context, callback, response.FAILED, {
                Error: err.message
              });
            } else {
              response.send(event, context, callback, response.SUCCESS);
            }
          }
        );
        break;
      case "Update":
        cognitoIdentityServiceProvider.describeUserPoolDomain(
          {
            Domain: event.ResourceProperties.Domain
          },
          function(err, data) {
            if (err) {
              console.log(err, err.stack);
              response.send(event, context, callback, response.FAILED, {
                Error: err.message
              });
            } else {
              if (data.DomainDescription.Domain) {
                cognitoIdentityServiceProvider.deleteUserPoolDomain(
                  {
                    UserPoolId: data.DomainDescription.UserPoolId,
                    Domain: event.ResourceProperties.Domain
                  },
                  function(err1, data1) {
                    if (err1) {
                      console.log(err1, err1.stack);
                      response.send(event, context, callback, response.FAILED, {
                        Error: err1.message
                      });
                    } else {
                      cognitoIdentityServiceProvider.createUserPoolDomain(
                        {
                          UserPoolId: event.ResourceProperties.UserPoolId,
                          Domain: event.ResourceProperties.Domain
                        },
                        function(err2, data2) {
                          if (err2) {
                            console.log(err2, err2.stack);
                            response.send(
                              event,
                              context,
                              callback,
                              response.FAILED,
                              {
                                Error: err2.message
                              }
                            );
                          } else {
                            response.send(
                              event,
                              context,
                              callback,
                              response.SUCCESS
                            );
                          }
                        }
                      );
                    }
                  }
                );
              } else {
                response.send(event, context, callback, response.FAILED);
              }
            }
          }
        );
        break;
      case "Delete":
        cognitoIdentityServiceProvider.describeUserPoolDomain(
          {
            Domain: event.ResourceProperties.Domain
          },
          function(err, data) {
            if (err) {
              console.log(err, err.stack);
              response.send(event, context, callback, response.FAILED, {
                Error: err.message
              });
            } else {
              if (data.DomainDescription.Domain) {
                cognitoIdentityServiceProvider.deleteUserPoolDomain(
                  {
                    UserPoolId: data.DomainDescription.UserPoolId,
                    Domain: event.ResourceProperties.Domain
                  },
                  function(err1, data1) {
                    if (err1) {
                      console.log(err1, err1.stack);
                      response.send(event, context, callback, response.FAILED, {
                        Error: err1.message
                      });
                    } else {
                      response.send(event, context, callback, response.SUCCESS);
                    }
                  }
                );
              } else {
                response.send(event, context, callback, response.FAILED);
              }
            }
          }
        );
        break;
    }
  } catch (error) {
    console.error(
      `CognitoUserPoolDomain Error for request type ${event.RequestType}:`,
      error
    );
    response.send(event, context, callback, response.FAILED, {
      Error: error.message
    });
  }
}
exports.handler = function(event, context, callback) {
  console.log(JSON.stringify("event ==> " + JSON.stringify(event, null, 4)));
  if (event.ResourceType === "Custom::CognitoUserPoolDomain") {
    cognitoUserPoolDomain(event, context, callback);
  } else if (event.ResourceType === "Custom::ElasticsearchCognitoOption") {
    elasticsearchCognitoOption(event, context, callback);
  }
};
