var AWS = require("aws-sdk");

var endpoint;
var creds = new AWS.EnvironmentCredentials("AWS");

Date.prototype.addDays = function(days) {
  var dat = new Date(this.valueOf());
  dat.setDate(dat.getDate() + days);
  return dat;
};

exports.handler = function(input, context) {
  endpoint = new AWS.Endpoint(process.env.ELASTICSEARCH_ENDPOINT);

  let dateBaseline = new Date();

  dateBaseline = dateBaseline.addDays(-parseInt(process.env.DAYS_TOKEEP));

  console.log("Date baseline: " + dateBaseline.toISOString());

  getIndices(context, function(data) {
    data.split("\n").forEach(row => {
      let parts = row.split(" ");

      if (parts.length > 2) {
        let indiceName = parts[2];

        if (indiceName.indexOf("cwl") > -1) {
          let indiceDate = new Date(
            indiceName.substr(4, 4),
            indiceName.substr(9, 2) - 1,
            indiceName.substr(12, 2)
          );

          if (indiceDate < dateBaseline) {
            console.log("Planning to delete indice: " + indiceName);

            removeIndice("/" + indiceName, context);
          }
        }
      }
    });
  });
};

function removeIndice(indiceName, context) {
  makeRequest("DELETE", indiceName, context);
}

function getIndices(context, callback) {
  makeRequest("GET", "/_cat/indices", context, callback);
}

function makeRequest(method, path, context, callback) {
  console.log(`Making ${method} call to ${path}`);

  var req = new AWS.HttpRequest(endpoint);

  req.method = method;
  req.path = path;
  req.region = process.env.AWS_REGION;
  req.headers["presigned-expires"] = false;
  req.headers["Host"] = endpoint.host;

  var signer = new AWS.Signers.V4(req, "es");
  signer.addAuthorization(creds, new Date());

  var send = new AWS.NodeHttpClient();
  send.handleRequest(
    req,
    null,
    function(httpResp) {
      var respBody = "";
      httpResp.on("data", function(chunk) {
        respBody += chunk;
      });
      httpResp.on("end", function(chunk) {
        if (callback) {
          callback(respBody);
        }
        //console.log(respBody);
      });
    },
    function(err) {
      console.log("Error: " + err);
      context.fail("Lambda failed with error " + err);
    }
  );
}
